﻿namespace ConsoleApp1
{
    class PersonBO
    {
        private List<PersonModel> people = new List<PersonModel>()
            {
                new PersonModel() { Id = 1001, Pname = "Arvind", Gender = "Male", Age = 20 },
                new PersonModel() { Id = 1002, Pname = "Bharathi", Gender = "Female", Age = 30 },
                new PersonModel() { Id = 1003, Pname = "Charan", Gender = "Male", Age = 40 }
            };
        public List<PersonModel> GetAll()
        {
            return people;
        }
        public void AddPerson(PersonModel p)
        {
            people.Add(p);
        }
    }
}





